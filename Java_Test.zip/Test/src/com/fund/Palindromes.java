package com.fund;

public class Palindromes {

	public static void main(String[] args) {
		
		for(int i=100; i<1000;i++ ) {
			if(i== reverse(i)) {
				System.out.println(i);
			}
		}

	}
	
	public static int reverse (int num) {
		int result =0;
		
		while(num>0 ) {
			result = result*10 + (num %10);
			num = num/10;
		}
		return result;
	}

}
