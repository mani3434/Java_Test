package com.fund;

import java.util.Scanner;

public class IPAddress {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
//		String v1 = sc.next();
//		String v2 = sc.next();
//		String v2a = sc.next();
		
		String a2v = "1000.43.59.96";
		String a1 = "10.0.0.1";
		String a2 = "11.199.88.254";
		
		
//		String a2v = "10.43.59.96";
//		String a1 = "10.0.0.1";
//		String a2 = "11.199.88.254";
		
		
		String cv [] = a2v.split("[.]");
		String c1 [] = a1.split("[.]");
		String c2 [] = a2.split("[.]");
		
		int i2v [] = new int[cv.length];
		int i1 [] = new int[c1.length];
		int i2 [] = new int[c2.length];
 		
		for(int i= 0; i<cv.length; i++) {
			
			i2v[i] = Integer.parseInt(cv[i]);
			i1[i] = Integer.parseInt(c1[i]);
			i2[i] = Integer.parseInt(c2[i]);
			
//			System.out.println(i2v[i]+" i2v");
//			System.out.println(i1[i]+" i1");
//			System.out.println(i2[i]+" i2");
			
		}
 		
		boolean f = false;
		
		int correct = 0; 
		int wrong = 0;
		
		//System.out.println(i2v[0]+" "+i1[0]+" "+i2[0]);
		if(i2v[0]>=i1[0] && i2v[0]<=i2[0]) {
			f = true;
			correct++;
			//System.out.println("inrange");
			}
		else {
			//System.out.println("outrange");
			f= false;
			correct--;
		}
		

		
		for(int i=1; i<i2v.length-1; i++) {
		
			if(i2v[i]<255 && i2v[i]>0) {
				f =true;
				correct++;
			}	
			
			else {
				f = true;
				wrong++;
			}
		}
		
		if(i2v[i2v.length-1]>=i1[i2v.length-1] && i2v[i2v.length-1]<i2[i2v.length-1]) {
			f = true;
			correct++;
			//System.out.println("inrange");
			}
		else {
			//System.out.println("outrange");
			f= false;
			correct--;
		}
		
		System.out.println(correct+" "+ wrong);
		if(correct == 4) {
			System.out.println("inrange");
		}
		else {
			System.out.println("outrange");
		}
	}

}
