package com.fund;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class SortArrayList {

	public static void main(String[] args) {
		
		
		List <Integer> list = new ArrayList<>();

		list.addAll(Arrays.asList(20, 12, 15, 14, 8, 10, 11, 25, 12, 14, 10));
		
		Collections.sort(list);
		
		Set<Integer> set = new TreeSet<>();
		
		set.addAll(list);
		
		
		System.out.println(set);
	}

}
