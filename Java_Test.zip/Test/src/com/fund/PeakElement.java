package com.fund;

import java.util.Scanner;

public class PeakElement {

	public static void main(String[] args) {
		
//		Scanner sc = new Scanner(System.in);
//		System.out.println("enter the no of test cases");
//		int  T = sc.nextInt();
		
	//	int a [] = {5, 10 ,20, 15};
		
		int a [] = {10, 20, 15, 2, 23,90, 67};
		int temp = a [0];
		
		int r = 0;
		for(int i=1; i<a.length -1; i++) {
			
			if(a[i]>a[i+1] && a[i] > a[i-1] ) {
				
				r = a[i];
			}
			
		}
		System.out.println(r);
		
		
	}
	
	public static int peak(int [] a) {
		
		
		
		
		return 0;
	}
}
