package com.fund;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.StringTokenizer;

public class Mail {

	public static void main(String[] args) throws UnsupportedEncodingException {

		String mail = "Caf�@Chaud.t�t";

		StringTokenizer st = new StringTokenizer(mail, "@");

		String a[] = new String[3];
		int i = 0;

		while (st.hasMoreTokens()) {
			a[i] = st.nextToken();
			i++;
		}

		String a2[] = a[1].split("[.]");

		a[1] = a2[0];
		a[2] = a2[1];

		for (String f : a) {

			System.out.println(f);

		}


		StringBuilder sb = new StringBuilder();
		

		for (int k = 0; k < a.length; k++) {

			for (int j = 0; j < a[k].length(); j++) {

				if (a[k].charAt(j) >= 32 && a[k].charAt(j) < 126) {

					sb.append(Character.toLowerCase(a[k].charAt(j)));

				} else {
					Charset.forName("UTF-8");
					char o = a[k].charAt(j);
					
					String hg = String.format("\\u%04x", (int) o);

					String s = "+" + j + hg.substring(4);

					sb.append(s);
				}

			}
			if(k == 0) {
				sb.append("@");
			}
			
			if(k==1) {
				sb.append(".");
			}

		}
		
		System.out.println(sb.toString());

	}

}
