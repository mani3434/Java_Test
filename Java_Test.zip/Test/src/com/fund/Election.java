package com.fund;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class Election {

	public static void main(String[] args) {

//		Scanner sc = new Scanner(System.in);
//
//		int noOfTestCases = sc.nextInt();
//		int t1L = sc.nextInt();
//		String [] t1 = new String[t1L];
//		
//		switch(noOfTestCases) {
//		
//		case 2:
//		{
//			for(int i=0; i<t1L; i++) {
//				
//				t1[i] = sc.next();
//			}
//		}
//	
//	}
//		
//		
//		
//		
//		
//		int t2L = sc.nextInt();
		
		
		
		
		//String [] t2 = new String [sc.nextInt()];
		
		
		String name [] = { "john", "johnny", "jackie", "johnny", "john", "jackie", "jamie", "jamie", "john", "johnny",
				"jamie", "johnny", "john" };
		
		String name2 []  = {"andy", "blake", "clark"};
		
		
		
		
		String r = result(name);
		System.out.println(r);
		
	
	
	}
	public static String result(String [] name) {
		
		Map<String, Integer> map = new TreeMap<>();

		for (int i = 0; i < name.length; i++) {

			if (map.containsKey(name[i])) {

				int count = map.get(name[i]);
				count++;
				map.put(name[i], count);
			} else {
				map.put(name[i], 1);
			}
		}
		
		
		List<Integer> li = new ArrayList<>(map.values());
		Collections.sort(li);
		Collections.reverse(li);
		
		
		List<String> sort = new ArrayList<>();
 		
		for(String g : map.keySet()) {
			
			if(map.get(g) == li.get(0)) {		
				sort.add(g);
			}	
		}
		
//		System.out.println(sort);
		
		//System.out.println(sort.get(0)+" "+li.get(0));
		
		String temp =sort.get(0)+" "+li.get(0);
		
		return temp;
	}

}
